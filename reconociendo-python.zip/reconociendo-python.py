num1 = 42  #declaracion de variable número entero
num2 = 2.3 #declaracion de variable número flotante
boolean = True #declaracion de variable con valor booleano
string = 'Hello World' #declaracion de variable con una cadena
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] # lista
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False} # diccionario
fruit = ('blueberry', 'strawberry', 'banana') # tupla
print(type(fruit)) #consultar tipo de dato dentro de una tupla
print(pizza_toppings[1]) #valor de una posicion dentro de una lista
pizza_toppings.append('Mushrooms') #agregar valor al final de la lista
print(person['name']) #posicion dentro de un diccionario
person['name'] = 'George' # cambiar clave-valor dentro de un diccionario
person['eye_color'] = 'blue' # agregar clave-valor dentro de un diccionario
print(fruit[2]) # valor de una posicion dentro de una tupla

if num1 > 45: #condicional con valor booleano
    print("It's greater")
else:
    print("It's lower")

if len(string) < 5: #condicional
    print("It's a short word!")
elif len(string) > 15:
    print("It's a long word!")
else:
    print("Just right!")

for x in range(5): #bucle for
    print(x)
for x in range(2,5):
    print(x)
for x in range(2,10,3):
    print(x)
x = 0
while(x < 5): #bucle while
    print(x)
    x += 1

pizza_toppings.pop() # remueve el ultimo valor
pizza_toppings.pop(1) # remueve el valor de la posicion (1)

print(person) #imprime una copia de diccionario 
person.pop('eye_color') #remueve la clave 'eye_color' y devuelve su valor = 'blue'
print(person) #print diccionario person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False}

for topping in pizza_toppings: #bucle for
    if topping == 'Pepperoni':
        continue
    print('After 1st if statement')
    if topping == 'Olives':
        break

def print_hello_ten_times(): #funcion con bucle for
    for num in range(10):
        print('Hello')

print_hello_ten_times() #llamada de funcion

def print_hello_x_times(x): #funcion con bucle for
    for num in range(x):
        print('Hello')

print_hello_x_times(4) # llamada de funcion

def print_hello_x_or_ten_times(x = 10):#funcion con bucle for
    for num in range(x):
        print('Hello')

print_hello_x_or_ten_times() 
print_hello_x_or_ten_times(4)


"""
Bonus section
"""

# print(num3)
# num3 = 72
# fruit[0] = 'cranberry'
# print(person['favorite_team'])
# print(pizza_toppings[7])
#   print(boolean)
# fruit.append('raspberry')
# fruit.pop(1)